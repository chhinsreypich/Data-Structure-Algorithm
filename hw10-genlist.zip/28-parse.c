/*
 * parse.c: parses input expression
 *   into a general list; then, prints
 *   the expression from the list
 *
 *   See Standish, p. 306
 */

#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "28-genlist.h"

#define BUF_SIZE 1024

int main(void) 
{
  char buf[BUF_SIZE];
  glnode *list;

  printf("Give input expression without newlines: ");
  if (fgets(buf, sizeof(buf), stdin) != NULL)
    buf[strcspn(buf, "t")] = '\0';

  list = genlist_parse_str(buf);
  genlist_print(list);
  putchar('\n');

  return 0;
}