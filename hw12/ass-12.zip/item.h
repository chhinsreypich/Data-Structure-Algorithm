#ifndef ITEM_H
#define ITEM_H

typedef char*  itemtype;// change to char*
int itemcmp(char* i, char* j);// change to char*
void print_arr(char* a[], size_t n);// change to char*

#endif