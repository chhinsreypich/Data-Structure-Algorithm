#ifndef SORT_ALG_H
#define SORT_ALG_H

#include "item.h"

void quicksort(char* a[], size_t left, size_t right); /// change to char*
#endif